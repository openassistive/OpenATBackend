"use strict";

var Client = require('github');
var async = require('async');
var gitAuthToken = require('./gitauth.json');
var repo_urls = require('./repo_urls.json');

// global variables
var line_of_text = "Definitions and / or widgets updated [" + new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '') + "]";
var file_to_change = "README.md";

// get access to github API
var github = new Client({
    debug: true
});

github.authenticate({
    type: "oauth",
    token: gitAuthToken.token
});

// update file from repo
var update_file = function(repo, file, cb) {
    github.repos.getContent({
        user: gitAuthToken.owner,
        //user: "WebPro9369",
        owner: gitAuthToken.owner,
        repo: repo,
        path: file,
        ref: "master"
    }, function(err, res) {
        if (err) {
            cb(err);
            return;
        }

        // append a line of text to the original content
        var origin_content = new Buffer(res.content, 'base64').toString();
        var new_content = new Buffer(origin_content + '\n' + "line_of_text").toString('base64');

        // update file with new content, commit - "timestampe: change FILENAME"
        github.repos.updateFile({
            user: gitAuthToken.owner,
            owner: gitAuthToken.owner,
            repo: repo,
            path: file,
            message: (new Date().getTime()) + ': change ' + file,
            content: new_content,
            branch: "master",
            sha: res.sha
        }, function(err, res) {
            cb(err);
        });
    });
}

// new sematic version (major.minor.patch)
function semantic_versioning(old_v) {
    var semantic_versions = old_v.replace(/^\D+/g, '').split('.');

    // minor increase by 0.1
    semantic_versions[1] = parseInt(semantic_versions[1]);
    semantic_versions[1]++;

    return "v" + semantic_versions.join('.');
}

// new release
var update_release = function(repo, cb) {
    github.repos.getLatestRelease({
        user: gitAuthToken.owner,
        owner: gitAuthToken.owner,
        repo: repo
    }, function(err, res) {
        if (err) {
            cb(err);
            return;
        }

        // build a new release
        github.repos.createRelease({
            user: gitAuthToken.owner,
            owner: gitAuthToken.owner,
            repo: repo,
            tag_name: semantic_versioning(res.tag_name),
            target_commitish: "master"
        }, function(err, res) {
            cb(err);
        });
    });
}

// parse repository url to get repo name
var getRepoNamefromUrl = function(repo_url) {
    var url = repo_url.split('/');
    return url[url.length - 1];
}

// process for 1 repository
var process_one_repo = function(repo_url, callback) {
    var repo_name = getRepoNamefromUrl(repo_url);

    update_file(repo_name, file_to_change, function(err) {
        if (err) throw err;

        update_release(repo_name, function(err) {
            if (err) throw err;
            callback();
        })
    });
}

// do for all repositories
async.eachSeries(repo_urls.repos_to_vupgrade, process_one_repo, function(err) {
    if (err) {
        console.log(err);
        return;
    }

    console.log("Complete!");
})

module.exports = {
    update_file: update_file,
    update_release: update_release
}