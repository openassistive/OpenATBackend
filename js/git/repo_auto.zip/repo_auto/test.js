var update_file = require('./automater.js').update_file;
var update_release = require('./automater.js').update_release;
var merge_staging = require('./automerge.js').merge_staging;

var update_file_mock = {
  "repo": "testrepo",
  "file": "change_log.md"
};

describe('update_file() function', function () {
  it('should succeed', function (done) {
    this.timeout(10000);

    update_file(update_file_mock.repo, update_file_mock.file, function (err) {
      if (err) throw err;
      done();
    });
  });
});

var update_release_mock = {
  "repo": "testrepo"
}

describe('update_release() function', function () {
  it('should succeed', function (done) {
    this.timeout(50000);

    update_release(update_release_mock.repo, function (err) {
      if (err) throw err;
      done();
    });
  });
});

var repo_to_merge = {
  "repourl": "https://github.com/appdev312/testrepo"
}

describe('merge_staging() function', function () {
  it('should succeed', function (done) {
    this.timeout(50000);

    merge_staging(repo_to_merge.repourl, function (err) {
      if (err) throw err;
      done();
    });
  });
});