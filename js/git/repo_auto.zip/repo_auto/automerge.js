"use strict";

var Client = require('github');
var async = require('async');
var gitAuthToken = require('./gitauth.json');
var repo_urls = require('./repo_urls.json');

// global variables
var branch_to_merge = "staging";

// get access to github API
var github = new Client({
	debug: true
});

github.authenticate({
	type: "oauth",
	token: gitAuthToken.token
});

// parse repository url to get repo name
var getRepoNamefromUrl = function(repo_url) {
	var url = repo_url.split('/');
	return url[url.length - 1];
}

// merge staging into master for 1 repository
var merge_staging = function (repo_url, callback)
{
	var repo_name = getRepoNamefromUrl(repo_url);

	github.repos.merge({
		user: gitAuthToken.owner,
		repo: repo_name,
		base: "master",
		head: branch_to_merge,
		commit_message: (new Date().getTime()) + ': ' + gitAuthToken.username + " has merged " + branch_to_merge + " into master branch."
	}, function(err, res){
		if (err)
		{
			callback(err);
			return;
		}

		console.log("Merging from " + branch_to_merge + " into master branch for " + repo_name + " repository has been performed!");
		callback();
	});
}

// do for all repositories
async.eachSeries(repo_urls.repos_to_merge, merge_staging, function(err)
{
	if (err)
	{
		console.log(err);
		return;
	}

	console.log("Complete Merging!");
});

module.exports = {
	merge_staging: merge_staging
}
